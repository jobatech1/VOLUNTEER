"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function HomePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set())
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [counters, setCounters] = useState({ students: 0, courses: 0, success: 0 })
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    setIsVisible(true)

    // Mouse tracking for interactive effects
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", handleMouseMove)

    // Intersection Observer for scroll animations
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections((prev) => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.1 },
    )

    // Observe all sections
    const sections = document.querySelectorAll("[data-animate]")
    sections.forEach((section) => observerRef.current?.observe(section))

    // Animated counters
    const animateCounters = () => {
      const duration = 2000
      const steps = 60
      const stepDuration = duration / steps

      let step = 0
      const timer = setInterval(() => {
        step++
        const progress = step / steps
        const easeOut = 1 - Math.pow(1 - progress, 3)

        setCounters({
          students: Math.floor(easeOut * 500),
          courses: Math.floor(easeOut * 50),
          success: Math.floor(easeOut * 95),
        })

        if (step >= steps) clearInterval(timer)
      }, stepDuration)
    }

    const timer = setTimeout(animateCounters, 1000)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      observerRef.current?.disconnect()
      clearTimeout(timer)
    }
  }, [])

  const roles = [
    {
      icon: "🎨",
      title: "Graphics Designers",
      description: "Create stunning visuals that inspire and engage",
      color: "from-pink-400 to-purple-600",
    },
    {
      icon: "🎬",
      title: "Video Editors",
      description: "Craft compelling stories through video",
      color: "from-blue-400 to-indigo-600",
    },
    {
      icon: "✍️",
      title: "Copywriters",
      description: "Write words that move and motivate",
      color: "from-green-400 to-teal-600",
    },
    {
      icon: "💼",
      title: "Sales Reps",
      description: "Connect with people and drive growth",
      color: "from-yellow-400 to-orange-600",
    },
    {
      icon: "📱",
      title: "Social Media Managers",
      description: "Build communities and amplify our voice",
      color: "from-purple-400 to-pink-600",
    },
    {
      icon: "⚡",
      title: "Admins & VAs",
      description: "Keep everything running smoothly",
      color: "from-cyan-400 to-blue-600",
    },
    {
      icon: "📅",
      title: "Project Coordinators",
      description: "Organize projects and guide teams to success",
      color: "from-red-400 to-pink-600",
    },
  ]

  const benefits = [
    {
      icon: "🔓",
      title: "Access to Our Exclusive Premium Content",
      description: "Courses, guides, templates, mentorship — all free for team members.",
    },
    {
      icon: "🌍",
      title: "International Trainings & Certifications",
      description: "We connect you to world-class learning experiences.",
    },
    {
      icon: "🔥",
      title: "Mentorship From Experienced Professionals",
      description: "You'll learn things most people pay heavily for.",
    },
    {
      icon: "💼",
      title: "Letters of Recommendation & Work Opportunities",
      description: "We don't keep quiet about our people. We promote you.",
    },
    {
      icon: "🤝",
      title: "Connections That Can Change Your Life",
      description: "You'll meet and work with people that open doors.",
    },
  ]

  const requirements = [
    { icon: "🧠", title: "A Teachable Mindset", description: "Ready to learn and grow with us" },
    { icon: "📱", title: "A Working Device", description: "Phone or laptop to get things done" },
    { icon: "💪", title: "Commitment", description: "Ready to show up and deliver" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 overflow-hidden">
      {/* Floating Elements */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div
          className="absolute w-64 h-64 bg-gradient-to-r from-orange-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"
          style={{
            left: mousePosition.x / 10,
            top: mousePosition.y / 10,
            transform: "translate(-50%, -50%)",
          }}
        />
        <div
          className="absolute w-96 h-96 bg-gradient-to-r from-purple-400/10 to-orange-400/10 rounded-full blur-3xl animate-pulse"
          style={{
            right: mousePosition.x / 15,
            bottom: mousePosition.y / 15,
            transform: "translate(50%, 50%)",
          }}
        />
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-orange-600 via-orange-500 to-purple-600 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
        <div className="relative container mx-auto px-4 py-20 text-center z-10">
          <div
            className={`transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            <Badge className="mb-6 bg-white/20 text-white border-white/30 hover:bg-white/30 transition-all duration-300 animate-bounce">
              🚀 Join Our Team Now
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight animate-fade-in-up">
              Want to Work With a<br />
              <span className="text-yellow-300 animate-pulse">Fast-Rising Tech Academy</span>
              <br />
              and Open New Doors?
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed opacity-90 animate-fade-in-up animation-delay-300">
              We're building something powerful at NextGen Tech Academy — training African teens in AI, coding, web
              design, and tech creativity for global relevance.
            </p>

            <div className="flex justify-center gap-8 mb-8 animate-fade-in-up animation-delay-500">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-300">{counters.students}+</div>
                <div className="text-sm opacity-80">Students Trained</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-300">{counters.courses}+</div>
                <div className="text-sm opacity-80">Courses Available</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-300">{counters.success}%</div>
                <div className="text-sm opacity-80">Success Rate</div>
              </div>
            </div>

            <Button
              size="lg"
              className="bg-white text-orange-600 hover:bg-orange-50 text-lg px-8 py-6 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 animate-bounce hover:animate-none group"
              onClick={() =>
                window.open(
                  "https://docs.google.com/forms/d/1blMwScHAD0_L1pUlQ_CjlJzmokoKpINVV7eSrmhXqO8/preview?pli=1",
                  "_blank",
                )
              }
            >
              <span className="group-hover:animate-pulse">Join Our Team Now 🚀</span>
            </Button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* We're Looking For Section */}
      <section className="py-20 container mx-auto px-4 relative z-10" id="roles" data-animate>
        <div className="text-center mb-16">
          <h2
            className={`text-4xl md:text-5xl font-bold text-gray-800 mb-4 transition-all duration-1000 ${visibleSections.has("roles") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            We're Looking For
          </h2>
          <p
            className={`text-xl text-gray-600 max-w-2xl mx-auto transition-all duration-1000 delay-200 ${visibleSections.has("roles") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            Passionate creatives and smart thinkers who want to grow while building something meaningful
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {roles.map((role, index) => (
            <Card
              key={index}
              className={`group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 hover:rotate-1 border-2 hover:border-orange-200 bg-gradient-to-br from-white to-orange-50/30 relative overflow-hidden ${visibleSections.has("roles") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-r ${role.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
              />
              <CardContent className="p-6 text-center relative z-10">
                <div className="text-4xl mb-4 group-hover:scale-125 group-hover:rotate-12 transition-all duration-300 animate-bounce group-hover:animate-none">
                  {role.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-orange-600 transition-colors duration-300">
                  {role.title}
                </h3>
                <p className="text-gray-600 group-hover:text-gray-700 transition-colors duration-300">
                  {role.description}
                </p>
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-orange-400 rounded-lg transition-all duration-300 animate-pulse opacity-0 group-hover:opacity-100" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Why Join Section */}
      <section
        className="py-20 bg-gradient-to-r from-purple-600 to-orange-600 text-white relative overflow-hidden"
        id="benefits"
        data-animate
      >
        <div className="absolute inset-0">
          <svg
            className="absolute bottom-0 w-full h-20 animate-pulse"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
              fill="currentColor"
            ></path>
            <path
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
              fill="currentColor"
            ></path>
            <path
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
              fill="currentColor"
            ></path>
          </svg>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div
            className={`text-center mb-16 transition-all duration-1000 ${visibleSections.has("benefits") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 animate-pulse">"But Why Should I Join?"</h2>
            <p className="text-xl max-w-3xl mx-auto leading-relaxed opacity-90">
              Let's be honest. You're not doing this just for fun. You want access, growth, and opportunity. We get that
              — and that's exactly what we're offering:
            </p>
          </div>

          <div className="mb-12">
            <h3
              className={`text-3xl font-bold text-center mb-8 text-yellow-300 transition-all duration-1000 delay-300 ${visibleSections.has("benefits") ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
            >
              💥 What You Get:
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {benefits.map((benefit, index) => (
                <Card
                  key={index}
                  className={`bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-500 group hover:scale-105 hover:-translate-y-2 relative overflow-hidden ${visibleSections.has("benefits") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
                  style={{ transitionDelay: `${index * 150}ms` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  <CardContent className="p-6 relative z-10">
                    <div className="text-3xl mb-4 group-hover:scale-125 group-hover:rotate-12 transition-all duration-300 animate-bounce group-hover:animate-spin">
                      {benefit.icon}
                    </div>
                    <h4 className="text-lg font-semibold mb-2 text-yellow-300 group-hover:text-yellow-200 transition-colors duration-300">
                      {benefit.title}
                    </h4>
                    <p className="text-white/90 text-sm group-hover:text-white transition-colors duration-300">
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* What We Want Section */}
      <section className="py-20 container mx-auto px-4 relative z-10" id="requirements" data-animate>
        <div
          className={`text-center mb-16 transition-all duration-1000 ${visibleSections.has("requirements") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">"But What Do You Want From Me?"</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We want team players. People who are ready to serve, grow, and show up. You don't need 10 years' experience.
            You just need:
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {requirements.map((req, index) => (
            <Card
              key={index}
              className={`text-center group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 hover:rotate-2 bg-gradient-to-br from-purple-50 to-orange-50 border-2 hover:border-purple-200 relative overflow-hidden ${visibleSections.has("requirements") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
              style={{ transitionDelay: `${index * 200}ms` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-orange-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-pulse" />
              <CardContent className="p-8 relative z-10">
                <div className="text-5xl mb-4 group-hover:scale-125 group-hover:animate-bounce transition-all duration-300">
                  {req.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3 group-hover:text-purple-600 transition-colors duration-300">
                  {req.title}
                </h3>
                <p className="text-gray-600 group-hover:text-gray-700 transition-colors duration-300">
                  {req.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div
          className={`text-center mt-12 transition-all duration-1000 delay-500 ${visibleSections.has("requirements") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <p className="text-lg text-gray-700 mb-6 animate-pulse">If that's you, we want you on the team.</p>
        </div>
      </section>

      {/* Call to Action Section */}
      <section
        className="py-20 bg-gradient-to-r from-orange-600 via-purple-600 to-orange-600 text-white relative overflow-hidden"
        id="cta"
        data-animate
      >
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="absolute inset-0">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${3 + Math.random() * 2}s`,
              }}
            >
              <div
                className="w-4 h-4 bg-white/10 rotate-45 animate-spin"
                style={{ animationDuration: `${2 + Math.random() * 2}s` }}
              />
            </div>
          ))}
        </div>

        <div className="relative container mx-auto px-4 text-center z-10">
          <h2
            className={`text-4xl md:text-5xl font-bold mb-6 transition-all duration-1000 ${visibleSections.has("cta") ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            This Can Open Doors
            <br />
            <span className="text-yellow-300 animate-pulse">You Didn't Expect</span>
          </h2>
          <p
            className={`text-xl mb-8 max-w-3xl mx-auto leading-relaxed opacity-90 transition-all duration-1000 delay-200 ${visibleSections.has("cta") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            Most of the opportunities I've gotten in life came from showing up early for something meaningful.
          </p>
          <p
            className={`text-2xl font-semibold mb-8 text-yellow-300 animate-bounce transition-all duration-1000 delay-400 ${visibleSections.has("cta") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            This is one of those moments.
          </p>
          <p
            className={`text-lg mb-12 max-w-2xl mx-auto opacity-90 transition-all duration-1000 delay-600 ${visibleSections.has("cta") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            If you want to join a team that's building the future — and you want to grow while doing it — then don't
            overthink this.
          </p>

          <div
            className={`space-y-6 transition-all duration-1000 delay-800 ${visibleSections.has("cta") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            <Button
              size="lg"
              className="bg-white text-orange-600 hover:bg-yellow-100 text-xl px-12 py-8 rounded-full font-bold shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse hover:animate-bounce group relative overflow-hidden"
              onClick={() =>
                window.open(
                  "https://docs.google.com/forms/d/1blMwScHAD0_L1pUlQ_CjlJzmokoKpINVV7eSrmhXqO8/preview?pli=1",
                  "_blank",
                )
              }
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              <span className="relative z-10 group-hover:animate-pulse">Click Here to Apply Now 🚀</span>
            </Button>
            <p className="text-sm opacity-75 animate-fade-in">
              Join hundreds of ambitious individuals already on this journey
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-900/20 to-purple-900/20 animate-pulse" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-orange-400 to-purple-400 bg-clip-text text-transparent animate-pulse">
            NextGen Tech Academy
          </h3>
          <p className="text-gray-400">Building the future, one student at a time.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
        .animate-fade-in-up {
          animation: fade-in-up 1s ease-out forwards;
        }
        .animate-fade-in {
          animation: fade-in 2s ease-out forwards;
        }
        .animation-delay-300 {
          animation-delay: 300ms;
        }
        .animation-delay-500 {
          animation-delay: 500ms;
        }
      `}</style>
    </div>
  )
}
